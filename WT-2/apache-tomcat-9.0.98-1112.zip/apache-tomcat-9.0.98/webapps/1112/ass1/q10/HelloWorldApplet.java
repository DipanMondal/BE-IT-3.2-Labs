import java.applet.Applet;
import java.awt.Graphics;

/* 
<applet code="HelloWorldApplet.class" width="300" height="100">
</applet>
*/

public class HelloWorldApplet extends Applet {
    public void paint(Graphics g) {
        g.drawString("Hello World", 50, 50);
    }
}
