import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet("/departments")
public class DepartmentServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:mysql://172.16.4.234:3306/test";
    private static final String DB_USER = "be22112";
    private static final String DB_PASS = "lmyrIqsD";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        JSONArray departments = new JSONArray();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            String query = "SELECT DISTINCT DEPT_ID FROM students";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                JSONObject dept = new JSONObject();
                dept.put("id", rs.getString("DEPT_ID"));
                dept.put("name", "Department " + rs.getString("DEPT_ID")); 
                departments.put(dept);
            }
            response.getWriter().print(departments.toString());
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().print("[]");
        }
    }
}

