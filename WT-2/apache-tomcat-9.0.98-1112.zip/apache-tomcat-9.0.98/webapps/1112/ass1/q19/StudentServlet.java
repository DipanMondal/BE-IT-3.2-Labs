import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/students")
public class StudentServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:mysql://172.16.4.234:3306/test";
    private static final String DB_USER = "be22112";
    private static final String DB_PASS = "lmyrIqsD";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        String name = request.getParameter("name");

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            String query = "SELECT * FROM students WHERE NAME LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, "%" + name + "%");
            ResultSet rs = stmt.executeQuery();

            response.getWriter().println("<h2>Students Matching: " + name + "</h2><ul>");
            while (rs.next()) {
                response.getWriter().println("<li>" + rs.getString("ROLL_NO") + " - " + rs.getString("NAME") + "</li>");
            }
            response.getWriter().println("</ul>");
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("<p>Error retrieving students.</p>");
        }
    }
}
