import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/stocks") // Endpoint for SSE
public class StockPriceServlet extends HttpServlet {

    private static final String[] STOCKS = {"AAPL", "GOOGL"};
    private static final Random random = new Random();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/event-stream");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();

        while (true) {
            try {
                Thread.sleep(2000); // Update stock prices every 2 seconds

                for (String stock : STOCKS) {
                    double price = 100 + random.nextDouble() * 50; // Generate random stock price
                    out.println("data: " + stock + " : $" + String.format("%.2f", price));
                    out.println(); // SSE requires a blank line
                    out.flush();
                }
            } catch (InterruptedException e) {
                break;
            }
        }
    }
}
